#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/fs.h>
#include <linux/uaccess.h>
#include <linux/ioctl.h>
#include <linux/cdev.h>
#include <linux/slab.h>  // For kmalloc and kfree
#include <linux/io.h>
#include <linux/mutex.h>
#include "flc_cmo.h"
#include <linux/of.h>i
#include <linux/init.h>
#include <linux/file.h>
#include <linux/spinlock.h>
#include <linux/platform_device.h>



#define FLC1_BASE_ADDR		0xF4010000
#define FLC1_MNT_REQ		0X004
#define FLC1_MNT_ADDR       	0x008
#define FLC1_MNT_ADDR_H   	0x00C
#define FLC1_MNT_STATUS     	0x030


#define FLC2_BASE_ADDR 	     	0xF4020000
#define FLC2_MNT_REQ        	0x004
#define FLC2_MNT_ADDR       	0x008
#define FLC2_MNT_ADDR_H     	0x00C
#define FLC2_MNT_STATUS     	0x010



struct flc_pm_device {
	void __iomem *base;
	struct cdev cdev;
	spinlock_t lock;
};
static dev_t dev_num = 0;
static struct cdev my_cdev;
static struct class *dev_class;
#if 0
static int int_value;
static long long_value;
static char str_value[256];
static float float_value;
static double double_value;
#endif
static int device_num = 0;

// Mutex for protecting shared resources
static DEFINE_MUTEX(dev_lock);
struct flc_pm_device *pm_dev;

static long device_ioctl(struct file *file, unsigned int cmd, unsigned long arg) {
    unsigned int pa_low, pa_high;
    unsigned int status;
    //struct flc_pm_device *pm_dev;
    struct flc_pm_device *pm_dev = file->private_data;
    if(!pm_dev)
	return -EINVAL;

    mutex_lock(&dev_lock);  // Acquire mutex before entering the critical section
    pr_info(" physical address from user 0x%lx\n",arg);
    switch (cmd) {

        case FLC1_CMO_LINEFILL_IO:
	
            // Get PA (Physical Address) from user
            pa_low = (arg >> 12) & 0xFFFFFFFF;
            pa_high = ((arg >> (32 + 12)) & 0xF);
	    pr_info("pa_low:%#x pa_high:%#x\n", pa_low, pa_high);

            // Write PA to FLC_Mnt_Addr and FLC_Mnt_Addr_H
            iowrite32(pa_low, (pm_dev->base) + FLC1_MNT_ADDR);
            iowrite32(pa_high, (pm_dev->base) + FLC1_MNT_ADDR_H);
            unsigned int pah = ioread32((pm_dev->base) + FLC1_MNT_ADDR_H);
	   // pr_info("pa_high %lx\n",pah);

            // Write the linefill request
            iowrite32(FLC_LINEFILL_REQUEST, (pm_dev->base) + FLC1_MNT_REQ);
	  
	    pr_info("After write to fcl1_mnt_req\n");
            status = ioread32((pm_dev->base) + FLC1_MNT_STATUS);
            pr_info("FLC1_MNT_STATUS: %x",status);

            // Poll FLC_Mnt_Status for completion
           // pr_info("Polling FLC_MNT_STATUS register\n");

           /* do {
                status = ioread32((pm_dev-> base) + FLC1_MNT_STATUS);
            } while (!(status));  // Wait for status[0] to be asserted  */
	     //pr_info("status bit %#x\n",status);
            break;

//	case FLC1_CMO_CLEAN:
//	    break;

        case FLC2_CMO_CLEAN_IO:
            // Get PA from user
            pa_low = (arg >> 14) & 0xFFFFFFFF;
	    pr_info("flc2_pa_low address is %#lx",pa_low);
            pa_high = ((arg >> (32 + 14)) & 0xF);
	    pr_info("flc2_pa_low address is %#lx",pa_high);

            // Write PA to FLC_Mnt_Addr and FLC_Mnt_Addr_H
            iowrite32(pa_low, ((pm_dev->base) + FLC2_MNT_ADDR));
            iowrite32(pa_high,((pm_dev->base) + FLC2_MNT_ADDR_H));
	    pr_info("After to FLC2_PA_HIgh AND FLC2_PA_LOW\n");

            // Write the clean request
            iowrite32(FLC_CLEAN_REQUEST, ((pm_dev->base) +FLC2_MNT_REQ));
	    status = ioread32((pm_dev->base) + FLC2_MNT_STATUS);
	    pr_info("FLC_MNT_STATUS: %X\n",status);

            // Poll FLC_Mnt_Status for completion
            do {
                status = ioread32((pm_dev->base) + FLC2_MNT_STATUS);
		pr_info("FLC2_MNT_STATUS: %X\n",status);
            } while (!(status & 0x40));  // Wait for status[6] to be asserted
            break;
#if 0
        case IOCTL_CMD1_WRITE:
            if (copy_from_user(&int_value, (int __user *)arg, sizeof(int_value))) {
                mutex_unlock(&dev_lock);  // Unlock before returning
                return -EFAULT;
            }
            break;

        case IOCTL_CMD1_READ:
            if (copy_to_user((int __user *)arg, &int_value, sizeof(int_value))) {
                mutex_unlock(&dev_lock);  // Unlock before returning
                return -EFAULT;
            }
            break;

        case IOCTL_CMD2_WRITE:
            if (copy_from_user(&long_value, (long __user *)arg, sizeof(long_value))) {
                mutex_unlock(&dev_lock);  // Unlock before returning
                return -EFAULT;
            }
            break;

        case IOCTL_CMD2_READ:
            if (copy_to_user((long __user *)arg, &long_value, sizeof(long_value))) {
                mutex_unlock(&dev_lock);  // Unlock before returning
                return -EFAULT;
            }
            break;

        case IOCTL_CMD3_WRITE:
            if (copy_from_user(str_value, (char __user *)arg, sizeof(str_value))) {
                mutex_unlock(&dev_lock);  // Unlock before returning
                return -EFAULT;
            }
            break;

        case IOCTL_CMD3_READ:
            if (copy_to_user((char __user *)arg, str_value, sizeof(str_value))) {
                mutex_unlock(&dev_lock);  // Unlock before returning
                return -EFAULT;
            }
            break;

        case IOCTL_CMD4_WRITE:
            if (copy_from_user(&float_value, (float __user *)arg, sizeof(float_value))) {
                mutex_unlock(&dev_lock);  // Unlock before returning
                return -EFAULT;
            }
            break;

        case IOCTL_CMD4_READ:
            if (copy_to_user((float __user *)arg, &float_value, sizeof(float_value))) {
                mutex_unlock(&dev_lock);  // Unlock before returning
                return -EFAULT;
            }
            break;

        case IOCTL_CMD5_WRITE:
            if (copy_from_user(&double_value, (double __user *)arg, sizeof(double_value))) {
                mutex_unlock(&dev_lock);  // Unlock before returning
                return -EFAULT;
            }
            break;

        case IOCTL_CMD5_READ:
            if (copy_to_user((double __user *)arg, &double_value, sizeof(double_value))) {
                mutex_unlock(&dev_lock);  // Unlock before returning
                return -EFAULT;
            }
            break;
#endif
        default:
            mutex_unlock(&dev_lock);  // Unlock before returning
            return -ENOTTY;
    }

    mutex_unlock(&dev_lock);  // Release mutex after critical section
    return 0;
}

static int device_open(struct inode *inode, struct file *file) {
    if (device_num) {
        return -EBUSY;
    }

    device_num++;
    try_module_get(THIS_MODULE);

    file->private_data = pm_dev;

    return 0;	
}

static int device_release(struct inode *inode, struct file *file) {
    device_num--;
    module_put(THIS_MODULE);
    return 0;
}

static struct file_operations fops = {
    .owner = THIS_MODULE,
    .unlocked_ioctl = device_ioctl,
    .open = device_open,
    .release = device_release,
};

static int __init flc_ioctl_init(void) {
    int result;
	printk(KERN_INFO, "[FLC_CMO] Enter into init funtion/n");
     //struct flc_pm_device *pm_dev; 
     //struct platform_device *pdev;
    // Allocate a major number dynamically
    result = alloc_chrdev_region(&dev_num, 0, 1, DEVICE_NAME);
    if (result < 0) {
        printk(KERN_ALERT "Failed to allocate device number\n");
        return result;
    }

     pm_dev = kzalloc(sizeof(struct flc_pm_device), GFP_KERNEL);
     if(!pm_dev) {
	pr_err("Failed to allocate memmory for device\n");
	return -ENOMEM;
	}


      spin_lock_init(&pm_dev->lock);

     pm_dev->base = ioremap(FLC1_BASE_ADDR, 0x400);
     if(!pm_dev->base) {
	pr_err("Failed to map memory\n");
	unregister_chrdev_region(dev_num, 1);
	kfree(pm_dev);
	return -ENOMEM;
     }
    // Initialize the character device
    cdev_init(&my_cdev, &fops);
    my_cdev.owner = THIS_MODULE;
    result = cdev_add(&my_cdev, dev_num, 1);
    if (result < 0) {
        unregister_chrdev_region(dev_num, 1);
        printk(KERN_ALERT "Failed to add character device\n");
        return result;
    }

    // Create the device class
    dev_class = class_create(THIS_MODULE, "flc_ioctl_class");
    if (IS_ERR(dev_class)) {
        cdev_del(&my_cdev);
        unregister_chrdev_region(dev_num, 1);
        printk(KERN_ALERT "Failed to create device class\n");
        return PTR_ERR(dev_class);
    }

    // Create the device node
    device_create(dev_class, NULL, dev_num, NULL, "flc_cmo");

    printk(KERN_INFO "Flc_cmo  major number %d and minor number %d\n",
           MAJOR(dev_num), MINOR(dev_num));
    return 0;
}

static void __exit flc_ioctl_exit(void) {
    device_destroy(dev_class, dev_num);
    class_destroy(dev_class);
    cdev_del(&my_cdev);
    iounmap(pm_dev->base);
    unregister_chrdev_region(dev_num, 1);
    printk(KERN_INFO "Unregistered mychardev\n");
}
static const struct of_device_id flc_cmo_of_match[] = {
	{.compatible = "flc,flc_cmo"},
	{/* sential */},
};
MODULE_DEVICE_TABLE(of, flc_cmo_of_match);

module_init(flc_ioctl_init);
module_exit(flc_ioctl_exit);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("FLC");
MODULE_DESCRIPTION("FLC CMO_linefull and CMO_clear sequences");


#ifndef _FLC_CMO_
#define _FLC_CMO_

#define DEVICE_FILE "/dev/flc_cmo"
#define DEVICE_NAME "flc_cmo"

#define FLC2_CMO_CLEAN_IO    _IOW('F', 1, unsigned long)
#define FLC1_CMO_LINEFILL_IO _IOW('F', 2, unsigned long)
#if 0
// Additional IOCTL commands
#define IOCTL_CMD1_WRITE _IOW ('a', 1, int)
#define IOCTL_CMD1_READ  _IOR ('a', 2, int)
#define IOCTL_CMD2_WRITE _IOW ('a', 3, long)
#define IOCTL_CMD2_READ  _IOR ('a', 4, long)
#define IOCTL_CMD3_WRITE _IOW ('a', 5, char[256])
#define IOCTL_CMD3_READ  _IOR ('a', 6, char[256])
#define IOCTL_CMD4_WRITE _IOW ('a', 7, float)
#define IOCTL_CMD4_READ  _IOR ('a', 8, float)
#define IOCTL_CMD5_WRITE _IOW ('a', 9, double)
#define IOCTL_CMD5_READ  _IOR ('a', 10, double)
#endif

#define FLC_LINEFILL_REQUEST 0x5
#define FLC_CLEAN_REQUEST    0x400

#if 0
// Define register addresses
#define FLC1_BASE_ADDR 	     0x22010000
#define FLC1_MNT_REQ        (FLC1_BASE_ADDR+ 0x004)  
#define FLC1_MNT_ADDR       (FLC1_BASE_ADDR+ 0x008)  
#define FLC1_MNT_ADDR_H     (FLC1_BASE_ADDR+ 0x00C) 
#define FLC1_MNT_STATUS     (FLC1_BASE_ADDR+ 0x030)  

#define FLC2_BASE_ADDR 	     0x22020000
#define FLC2_MNT_REQ        (FLC2_BASE_ADDR+ 0x004)  
#define FLC2_MNT_ADDR       (FLC2_BASE_ADDR+ 0x008)  
#define FLC2_MNT_ADDR_H     (FLC2_BASE_ADDR+ 0x00C) 
#define FLC2_MNT_STATUS     (FLC2_BASE_ADDR+ 0x010)
#endif
#endif /* _FLC_IOCTL_ */

#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <string.h>
#include <errno.h>
#include "flc_cmo.h"
void flc_linefill(int fd, unsigned long pa) {
    int ret;

    printf("Performing FLC1 CMO Linefill on PA: 0x%lx\n", pa);

    ret = ioctl(fd, FLC1_CMO_LINEFILL_IO, pa);
   // printf("line fille operation done\n");
    if (ret < 0) {
        perror("FLC1 CMO Linefill ioctl failed");
        exit(EXIT_FAILURE);
    } else {
        printf("FLC1 CMO Linefill success\n");
    }
}

void flc_clean(int fd, unsigned long pa) {
    int ret;

    printf("Performing FLC2 CMO Clean on PA: 0x%lx\n", pa);

    ret = ioctl(fd, FLC2_CMO_CLEAN_IO, pa);
    if (ret < 0) {
        perror("FLC2 CMO Clean ioctl failed");
        exit(EXIT_FAILURE);
    } else {
        printf("FLC2 CMO Clean success\n");
    }
}
#if 0
void perform_additional_ioctls(int fd) {
    int int_value = 100;
    long long_value = 123456789L;
    char str_value[256] = "Hello from user space!";
    float float_value = 3.14f;
    double double_value = 2.71828;

    // IOCTL_CMD1_WRITE: Write an integer
    if (ioctl(fd, IOCTL_CMD1_WRITE, &int_value) == -1) {
        perror("IOCTL_CMD1_WRITE failed");
        return;
    }

    // IOCTL_CMD1_READ: Read an integer
    if (ioctl(fd, IOCTL_CMD1_READ, &int_value) == -1) {
        perror("IOCTL_CMD1_READ failed");
        return;
    }
    printf("IOCTL_CMD1_READ: Read integer value %d\n", int_value);

    // IOCTL_CMD2_WRITE: Write a long
    if (ioctl(fd, IOCTL_CMD2_WRITE, &long_value) == -1) {
        perror("IOCTL_CMD2_WRITE failed");
        return;
    }

    // IOCTL_CMD2_READ: Read a long
    if (ioctl(fd, IOCTL_CMD2_READ, &long_value) == -1) {
        perror("IOCTL_CMD2_READ failed");
        return;
    }
    printf("IOCTL_CMD2_READ: Read long value %ld\n", long_value);

    // IOCTL_CMD3_WRITE: Write a string
    if (ioctl(fd, IOCTL_CMD3_WRITE, str_value) == -1) {
        perror("IOCTL_CMD3_WRITE failed");
        return;
    }

    // IOCTL_CMD3_READ: Read a string
    if (ioctl(fd, IOCTL_CMD3_READ, str_value) == -1) {
        perror("IOCTL_CMD3_READ failed");
        return;
    }
    printf("IOCTL_CMD3_READ: Read string value: %s\n", str_value);

    // IOCTL_CMD4_WRITE: Write a float
    if (ioctl(fd, IOCTL_CMD4_WRITE, &float_value) == -1) {
        perror("IOCTL_CMD4_WRITE failed");
        return;
    }

    // IOCTL_CMD4_READ: Read a float
    if (ioctl(fd, IOCTL_CMD4_READ, &float_value) == -1) {
        perror("IOCTL_CMD4_READ failed");
        return;
    }
    printf("IOCTL_CMD4_READ: Read float value: %.2f\n", float_value);

    // IOCTL_CMD5_WRITE: Write a double
    if (ioctl(fd, IOCTL_CMD5_WRITE, &double_value) == -1) {
        perror("IOCTL_CMD5_WRITE failed");
        return;
    }

    // IOCTL_CMD5_READ: Read a double
    if (ioctl(fd, IOCTL_CMD5_READ, &double_value) == -1) {
        perror("IOCTL_CMD5_READ failed");
        return;
    }
    printf("IOCTL_CMD5_READ: Read double value: %.5f\n", double_value);
}
#endif
int main(int argc, char *argv[]) {
    int fd;
    unsigned long pa;
    if (argc != 3) {
        fprintf(stderr, "Usage: %s <operation> <physical_address>\n", argv[0]);
        fprintf(stderr, "Operations: linefill, clean, additional\n");
        return EXIT_FAILURE;
    }

    // Open the device file
    fd = open(DEVICE_FILE, O_RDWR);
    if (fd < 0) {
        perror("Failed to open device");
        return EXIT_FAILURE;
    }

    // If additional commands are requested
    if (strcmp(argv[1], "additional") == 0) {
      //  perform_additional_ioctls(fd);
    } else {
        // Get the physical address from the command line argument
        pa = strtoul(argv[2], NULL, 16);

        // Perform the requested operation
        if (strcmp(argv[1], "linefill") == 0) {
            flc_linefill(fd, pa);
        } else if (strcmp(argv[1], "clean") == 0) {
            flc_clean(fd, pa);
        } else {
            fprintf(stderr, "Unknown operation: %s\n", argv[1]);
            close(fd);
            return EXIT_FAILURE;
        }
    }

    // Close the device file
    close(fd);
    return EXIT_SUCCESS;
}


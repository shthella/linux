#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/platform_device.h>
#include <linux/io.h>
#include <linux/spinlock.h>
#include <linux/interrupt.h>
#include <linux/fs.h>
#include <linux/uaccess.h>
#include <linux/cdev.h>
#include <linux/device.h>
#include <linux/file.h>
#include <linux/init.h>
#include <linux/of.h>




#define DEVICE_NAME "flc_perfmon"
#define CLASS_NAME "flc"
#define DEVICE_COUNT 1

// Define register offsets
#define FLC1_BASE_ADDR           0x22010000
#define FLC_PM_CONTROL_0         0x344
#define FLC_PM_COUNTDOWN         0x348
#define FLC_PM_COUNTDOWN_H       0x34C
#define FLC_PM_WEIGHT            0x368
#define FLC_PC_CONTROL           0x36C 
#define FLC_IER                  0x23C 
#define FLC_ISR                  0x238 


struct flc_pm_device {
    void __iomem *base;
    struct cdev cdev;
    spinlock_t lock;
};

static struct class *flc_class;
static struct device *flc_device;
static dev_t dev_num;
static struct cdev flc_cdev;


// Function to configure performance monitor

static void configure_performance_monitor(struct flc_pm_device *dev) {
    unsigned long flags;
    uint32_t value; 

    spin_lock_irqsave(&dev->lock, flags);  // Acquire lock with IRQ disabled
    
 
    // Step 1: Disable Performance Monitor
    iowrite32(ioread32(dev->base + FLC_PM_CONTROL_0) & ~(0x3), dev->base + FLC_PM_CONTROL_0);
    
    // Step 2: Define measurement window
    iowrite32(0x5c8a, dev->base + FLC_PM_COUNTDOWN);       // Write 'h5c8a to Countdown
    iowrite32(0x0, dev->base + FLC_PM_COUNTDOWN_H);        // Write 'h0 to Countdown_H

    // Step 3: Program threshold ratio
    value = (0x17 << 16) | 0x2E;  
    iowrite32(value, dev->base + FLC_PM_WEIGHT);

    // Step 4: Program Performance Counter Control Register
    value = ioread32(dev->base + FLC_PC_CONTROL);
    value |= (1 << 0);   // Enable performance counter
    value &= ~(0x7 << 16);  // Clear event select bits
    iowrite32(value, dev->base + FLC_PC_CONTROL);

    // Step 5: Raise interrupt if event_a_count/event_b_count < threshold_ratio
    value = ioread32(dev->base + FLC_PM_CONTROL_0);
    value |= (1 << 21);  // Enable interrupt for ratio threshold
    iowrite32(value, dev->base + FLC_PM_CONTROL_0);

    // Step 6: Disable TID filtering
    value = ioread32(dev->base + FLC_PM_CONTROL_0);
    value &= ~(1 << 15);  // Clear TID filtering bit
    iowrite32(value, dev->base + FLC_PM_CONTROL_0);

    // Step 7: Select events to track
   value = ioread32(dev->base + FLC_PM_CONTROL_0);

    value &= ~((0x1F << 10) | (0x1F << 5));

    value |= (0x0 << 10);

    value |= (0x1 << 5);

    iowrite32(value, dev->base + FLC_PM_CONTROL_0);
    // Step 8: Enable interrupt on counter overflow
    value = ioread32(dev->base + FLC_PM_CONTROL_0);
    value &= ~(1 << 3);  // Enable overflow interrupt
    iowrite32(value, dev->base + FLC_PM_CONTROL_0);

    // Step 9: Select Mode - Write 2'b10 to FLC_PM_Control_0.mode_select
    iowrite32((ioread32(dev->base + FLC_PM_CONTROL_0) & ~0x3) | 0x2, dev->base + FLC_PM_CONTROL_0);
    

    spin_unlock_irqrestore(&dev->lock, flags);  // Release lock and restore IRQs

    printk(KERN_INFO "Performance Monitor configured in Mode 2.\n");
}

// Function to check performance monitor status
static void check_pm_status(struct flc_pm_device *dev) {
    unsigned int status = ioread32(dev->base + FLC_PM_CONTROL_0 + 0x20);
    printk(KERN_INFO "PM Done Status: 0x%x\n", status);

    if (ioread32(dev->base + FLC_IER) & (1 << 25)) {
        if (ioread32(dev->base + FLC_ISR) & (1 << 25)) {
            printk(KERN_INFO "Interrupt: event_a_count/event_b_count ratio < threshold.\n");
        }
    }
}

static ssize_t flc_perfmon_read(struct file *file, char __user *buf, size_t len, loff_t *offset) {
	printk(KERN_INFO "Enter into read function\n");
    struct flc_pm_device *pm_dev = file->private_data;
    uint32_t control_reg = ioread32(pm_dev->base + FLC_PM_CONTROL_0);
    uint32_t flc_access_count, flc_hit_count;
    char output[64];
    int ret;

    // Extract bits for access count (10 to 14) and hit count (5 to 9)
    flc_access_count = (control_reg >> 10) & 0x1F; // 5 bits for access count
    flc_hit_count = (control_reg >> 5) & 0x1F; // 5 bits for hit count

    ret = snprintf(output, sizeof(output), "Access Count: %u\nHit Count: %u\n", flc_access_count, flc_hit_count);

    // Copy output to user space
    if (copy_to_user(buf, output, ret)) {
        return -EFAULT;
    }

    return ret; // Return the number of bytes read
}

static int flc_perfmon_open(struct inode *ip, struct file *file)
{
        printk(KERN_INFO "flc_perfmon_read\n");
	struct flc_pm_device *pm_dev = container_of(ip->i_cdev,
				struct flc_pm_device, cdev);

	file->private_data = pm_dev;
	pr_info("[%s:%u]\n", __func__, __LINE__);

        return 0;
}

// File operations structure
static struct file_operations fops = {
    .owner = THIS_MODULE,
    .read = flc_perfmon_read,
    .open = flc_perfmon_open,
};

// Probe function
// Probe function

static int flc_perfmon_probe(struct platform_device *pdev) {
    struct flc_pm_device *pm_dev;
    struct resource *res;
    printk("[%s] [%s:%u]\n",__func__,__LINE__);
    printk(KERN_ERR "Enter into probe fucntion\n");

    pm_dev = devm_kzalloc(&pdev->dev, sizeof(struct flc_pm_device), GFP_KERNEL);
    if (!pm_dev) {
        pr_err("Failed to allocate memory for device\n");
        return -ENOMEM;
    }

    spin_lock_init(&pm_dev->lock);
    /*res = platform_get_resource(pdev, IORESOURCE_MEM, 0);
    if (!res) {
        printk(KERN_ERR "Failed to get memory resource\n");
        return -ENODEV;
    }*/

    pm_dev->base = ioremap(FLC1_BASE_ADDR, 0x400);  // Map 1KB of space
    if (!pm_dev->base) {
        pr_err("Failed to map memory region\n");
        return -ENOMEM;
    }

    // Initialize and add the character device
    cdev_init(&pm_dev->cdev, &fops); // Initialize cdev with fops
    pm_dev->cdev.owner = THIS_MODULE;

    printk(KERN_ERR "cdev_inti\n");

    if (cdev_add(&pm_dev->cdev, dev_num, DEVICE_COUNT) < 0) {
        pr_err("Failed to add cdev\n");
        return -ENOMEM;
    }

    flc_class = class_create(THIS_MODULE ,CLASS_NAME);
    if (IS_ERR(flc_class)) {
        cdev_del(&pm_dev->cdev);
        unregister_chrdev_region(dev_num, DEVICE_COUNT);
        pr_err("Failed to create class\n");
        return PTR_ERR(flc_class);
    }

    flc_device = device_create(flc_class, NULL, dev_num, NULL, DEVICE_NAME);
    if (IS_ERR(flc_device)) {
        class_destroy(flc_class);
        cdev_del(&pm_dev->cdev);
        unregister_chrdev_region(dev_num, DEVICE_COUNT);
        return PTR_ERR(flc_device);
    }

    // Save device data in file's private data
    flc_device->driver_data = pm_dev;

    platform_set_drvdata(pdev, pm_dev);
    
    //printk(KERN_ERR "FLC performace mointer driver probed\n");
	pr_info("perfmon_prob\n");
    printk(KERN_INFO "FLC Performance Monitor driver probed.\n");

 //   configure_performance_monitor(pm_dev);
   // check_pm_status(pm_dev);

    return 0;
}
// Remove function
static int flc_perfmon_remove(struct platform_device *pdev) {
    struct flc_pm_device *pm_dev = platform_get_drvdata(pdev);
    device_destroy(flc_class, dev_num);  // Destroy the device
    class_destroy(flc_class);              // Destroy the class
    cdev_del(&pm_dev->cdev);                   // Remove cdev
    unregister_chrdev_region(dev_num, DEVICE_COUNT);  // Free the device number
    iounmap(pm_dev->base);                 // Unmap memory region
    printk(KERN_INFO "FLC Performance Monitor driver removed.\n");
    return 0;
}

static const struct of_device_id flc_perfmon_of_match[] = {
	{.compatible = "flc,flc_perfmon"},
	{ /* sentinel */},
};
MODULE_DEVICE_TABLE(of, flc_perfmon_of_match);

// Platform driver structure
static struct platform_driver flc_perfmon_driver = {
    .driver = {
        .name = DEVICE_NAME,
        .owner = THIS_MODULE,
	.of_match_table = flc_perfmon_of_match,
    },
    .probe = flc_perfmon_probe,
    .remove = flc_perfmon_remove,
};

// Module initialization function
static int __init flc_perfmon_init(void) {
    int ret;
    printk(KERN_INFO "Enter to init function\n");
    ret = alloc_chrdev_region(&dev_num, 0, DEVICE_COUNT, DEVICE_NAME);
   printk(KERN_INFO "Major = %d, Minor = %d\n",MAJOR(dev_num), MINOR(dev_num));
    if (ret < 0) {
        printk(KERN_ALERT "Failed to allocate device number\n");
        return ret;
    }

    ret = platform_driver_register(&flc_perfmon_driver);
	
    printk(KERN_INFO "perfmon_init function\n");
    if (ret) {
        unregister_chrdev_region(dev_num, DEVICE_COUNT);
    }
	
    printk(KERN_INFO "perform_init function End\n");
    return ret;
}

// Module exit function
static void __exit flc_perfmon_exit(void) {
    platform_driver_unregister(&flc_perfmon_driver);
    class_destroy(flc_class);  // Destroy the class
    unregister_chrdev_region(dev_num, DEVICE_COUNT);  // Free the device number
}

module_init(flc_perfmon_init);
module_exit(flc_perfmon_exit);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("FLC");
MODULE_DESCRIPTION("FL1C Performance Monitor Mode 2 Driver with Device Class Creation");


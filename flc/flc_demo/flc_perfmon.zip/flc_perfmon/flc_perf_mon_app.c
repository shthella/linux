#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>

#define DEVICE_FILE "/dev/flc_perfmon" // The device file created by your driver

int main() {
    int fd;
    char buffer[64];
    ssize_t bytes_read;

    // Open the device file
    printf("opening  the device file\n");
    fd = open(DEVICE_FILE, O_RDWR);
    if (fd < 0) {
        perror("Failed to open device file");
        return EXIT_FAILURE;
    }

    // Read data from the device
    bytes_read = read(fd, buffer, sizeof(buffer) - 1);
    if (bytes_read < 0) {
        perror("Failed to read from device");
        close(fd);
        return EXIT_FAILURE;
    }

    // Null-terminate the buffer to safely print as a string
    buffer[bytes_read] = '\0';

    // Print the read data
    printf("Data from device:\n%s", buffer);

    // Close the device file
    close(fd);
    return EXIT_SUCCESS;
}


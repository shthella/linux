#include <linux/module.h>
#define INCLUDE_VERMAGIC
#include <linux/build-salt.h>
#include <linux/elfnote-lto.h>
#include <linux/export-internal.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

#ifdef CONFIG_UNWINDER_ORC
#include <asm/orc_header.h>
ORC_HEADER;
#endif

BUILD_SALT;
BUILD_LTO_INFO;

MODULE_INFO(vermagic, VERMAGIC_STRING);
MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(".gnu.linkonce.this_module") = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef CONFIG_RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif



static const char ____versions[]
__used __section("__versions") =
	"\x1c\x00\x00\x00\xd7\x22\x7f\x58"
	"devmap_managed_key\0\0"
	"\x18\x00\x00\x00\xb6\x09\x61\x8b"
	"pci_save_state\0\0"
	"\x14\x00\x00\x00\x3b\x4a\x51\xc1"
	"free_irq\0\0\0\0"
	"\x18\x00\x00\x00\x59\xb5\x0a\xc8"
	"swake_up_one\0\0\0\0"
	"\x1c\x00\x00\x00\x39\x40\x4d\x8a"
	"get_user_pages_fast\0"
	"\x14\x00\x00\x00\xf3\xf5\x8a\xa7"
	"ioread32\0\0\0\0"
	"\x1c\x00\x00\x00\x2b\x2f\xec\xe3"
	"alloc_chrdev_region\0"
	"\x1c\x00\x00\x00\x48\x9f\xdb\x88"
	"__check_object_size\0"
	"\x18\x00\x00\x00\xc3\x64\x14\x61"
	"param_ops_uint\0\0"
	"\x18\x00\x00\x00\xc2\x9c\xc4\x13"
	"_copy_from_user\0"
	"\x1c\x00\x00\x00\x9e\x04\x38\xd9"
	"pci_enable_device\0\0\0"
	"\x14\x00\x00\x00\x53\x3f\x45\x4a"
	"iowrite32\0\0\0"
	"\x1c\x00\x00\x00\x8f\x18\x02\x7f"
	"__msecs_to_jiffies\0\0"
	"\x20\x00\x00\x00\x74\x0c\x88\x8b"
	"pci_enable_device_mem\0\0\0"
	"\x14\x00\x00\x00\x51\x0b\xec\x56"
	"pci_iomap\0\0\0"
	"\x20\x00\x00\x00\x79\x76\x5f\x1f"
	"pci_alloc_irq_vectors\0\0\0"
	"\x14\x00\x00\x00\x6e\x4a\x6e\x65"
	"snprintf\0\0\0\0"
	"\x18\x00\x00\x00\x36\xf2\xb6\xc5"
	"queue_work_on\0\0\0"
	"\x18\x00\x00\x00\x86\x50\xc8\xc8"
	"sg_free_table\0\0\0"
	"\x20\x00\x00\x00\x2c\x8a\xd8\x48"
	"__SCT__preempt_schedule\0"
	"\x20\x00\x00\x00\xb5\x41\x87\x60"
	"__init_swait_queue_head\0"
	"\x14\x00\x00\x00\xbf\x0f\x54\x92"
	"finish_wait\0"
	"\x18\x00\x00\x00\xe3\xe5\x01\x99"
	"class_destroy\0\0\0"
	"\x20\x00\x00\x00\xf9\x79\x49\x79"
	"__pci_register_driver\0\0\0"
	"\x18\x00\x00\x00\xfc\x5b\xa1\x57"
	"pci_disable_msi\0"
	"\x1c\x00\x00\x00\xf1\xaa\xf1\x6d"
	"kernel_sigaction\0\0\0\0"
	"\x1c\x00\x00\x00\xaf\x85\x3b\xc7"
	"pci_request_regions\0"
	"\x18\x00\x00\x00\xc3\xde\x1a\xb2"
	"remap_pfn_range\0"
	"\x10\x00\x00\x00\xba\x0c\x7a\x03"
	"kfree\0\0\0"
	"\x14\x00\x00\x00\x64\xe9\x7e\x89"
	"pcpu_hot\0\0\0\0"
	"\x28\x00\x00\x00\xfc\x24\x7b\x2b"
	"__put_devmap_managed_page_refs\0\0"
	"\x20\x00\x00\x00\x95\xd4\x26\x8c"
	"prepare_to_wait_event\0\0\0"
	"\x1c\x00\x00\x00\x6e\x64\xf7\xb3"
	"kthread_should_stop\0"
	"\x14\x00\x00\x00\x44\x43\x96\xe2"
	"__wake_up\0\0\0"
	"\x18\x00\x00\x00\x76\x1a\x06\xa2"
	"pci_irq_vector\0\0"
	"\x1c\x00\x00\x00\x2b\xcc\x51\x67"
	"kmem_cache_create\0\0\0"
	"\x20\x00\x00\x00\x0b\x05\xdb\x34"
	"_raw_spin_lock_irqsave\0\0"
	"\x1c\x00\x00\x00\x53\x54\x9a\xb1"
	"__per_cpu_offset\0\0\0\0"
	"\x18\x00\x00\x00\x64\xbd\x8f\xba"
	"_raw_spin_lock\0\0"
	"\x20\x00\x00\x00\x1b\x6e\x1a\xb0"
	"pci_unregister_driver\0\0\0"
	"\x18\x00\x00\x00\x8c\x89\xd4\xcb"
	"fortify_panic\0\0\0"
	"\x14\x00\x00\x00\xbb\x6d\xfb\xbd"
	"__fentry__\0\0"
	"\x18\x00\x00\x00\x18\x5f\x46\xbe"
	"wake_up_process\0"
	"\x24\x00\x00\x00\x97\x70\x48\x65"
	"__x86_indirect_thunk_rax\0\0\0\0"
	"\x10\x00\x00\x00\x7e\x3a\x2c\x12"
	"_printk\0"
	"\x20\x00\x00\x00\x71\x05\x37\x04"
	"prepare_to_swait_event\0\0"
	"\x18\x00\x00\x00\x81\xc8\x24\x1d"
	"___ratelimit\0\0\0\0"
	"\x1c\x00\x00\x00\xad\x8a\xdd\x8d"
	"schedule_timeout\0\0\0\0"
	"\x14\x00\x00\x00\x51\x0e\x00\x01"
	"schedule\0\0\0\0"
	"\x18\x00\x00\x00\xf2\x86\xb9\x9c"
	"vmalloc_base\0\0\0\0"
	"\x1c\x00\x00\x00\xcb\xf6\xfd\xf0"
	"__stack_chk_fail\0\0\0\0"
	"\x18\x00\x00\x00\xeb\x5c\xfd\xb2"
	"__put_user_4\0\0\0\0"
	"\x14\x00\x00\x00\xfc\x11\x89\x61"
	"numa_node\0\0\0"
	"\x1c\x00\x00\x00\x86\xc6\xaf\x42"
	"kmem_cache_alloc\0\0\0\0"
	"\x28\x00\x00\x00\xb3\x1c\xa2\x87"
	"__ubsan_handle_out_of_bounds\0\0\0\0"
	"\x18\x00\x00\x00\xa8\x85\xf9\xb3"
	"sg_alloc_table\0\0"
	"\x14\x00\x00\x00\x95\x76\xdc\xa2"
	"cdev_add\0\0\0\0"
	"\x28\x00\x00\x00\xe4\x6f\xb3\xbc"
	"hugetlb_optimize_vmemmap_key\0\0\0\0"
	"\x1c\x00\x00\x00\xab\xdc\xc4\x53"
	"pci_find_capability\0"
	"\x18\x00\x00\x00\x75\x79\x48\xfe"
	"init_wait_entry\0"
	"\x14\x00\x00\x00\x1d\x8a\x37\x98"
	"cc_mkdec\0\0\0\0"
	"\x18\x00\x00\x00\x21\x2c\xea\xee"
	"pci_enable_msi\0\0"
	"\x18\x00\x00\x00\x7f\x79\x91\x60"
	"synchronize_rcu\0"
	"\x20\x00\x00\x00\x8e\x83\xd5\x92"
	"request_threaded_irq\0\0\0\0"
	"\x18\x00\x00\x00\xf9\x31\xa1\x23"
	"device_create\0\0\0"
	"\x18\x00\x00\x00\x73\xe0\x38\x00"
	"class_create\0\0\0\0"
	"\x1c\x00\x00\x00\x63\xa5\x03\x4c"
	"random_kmalloc_seed\0"
	"\x18\x00\x00\x00\xd8\x5d\x0b\x66"
	"finish_swait\0\0\0\0"
	"\x14\x00\x00\x00\x4b\x8d\xfa\x4d"
	"mutex_lock\0\0"
	"\x18\x00\x00\x00\x93\x8d\x91\x45"
	"kmem_cache_free\0"
	"\x18\x00\x00\x00\xcb\x0b\x7d\x0f"
	"dma_alloc_attrs\0"
	"\x20\x00\x00\x00\xe4\x84\x63\xeb"
	"pci_read_config_word\0\0\0\0"
	"\x28\x00\x00\x00\xd4\x5b\xbb\x07"
	"pci_aer_clear_nonfatal_status\0\0\0"
	"\x18\x00\x00\x00\xd9\xe8\xa1\x53"
	"_find_next_bit\0\0"
	"\x1c\x00\x00\x00\x71\x22\x5a\x5a"
	"__cpu_online_mask\0\0\0"
	"\x18\x00\x00\x00\x3d\xd0\xd3\xc0"
	"kthread_stop\0\0\0\0"
	"\x1c\x00\x00\x00\xeb\x16\xf2\xfe"
	"_raw_spin_trylock\0\0\0"
	"\x18\x00\x00\x00\x9f\x0c\xfb\xce"
	"__mutex_init\0\0\0\0"
	"\x24\x00\x00\x00\x70\xce\x5c\xd3"
	"_raw_spin_unlock_irqrestore\0"
	"\x14\x00\x00\x00\x3d\x78\x0b\xe0"
	"pci_iounmap\0"
	"\x1c\x00\x00\x00\x42\x09\x5f\xaa"
	"pci_restore_state\0\0\0"
	"\x10\x00\x00\x00\xc5\x8f\x57\xfb"
	"memset\0\0"
	"\x18\x00\x00\x00\x68\x48\x58\x3b"
	"pci_set_master\0\0"
	"\x1c\x00\x00\x00\xca\x39\x82\x5b"
	"__x86_return_thunk\0\0"
	"\x14\x00\x00\x00\xd5\xe3\x7d\x01"
	"nr_cpu_ids\0\0"
	"\x18\x00\x00\x00\xe1\xbe\x10\x6b"
	"_copy_to_user\0\0\0"
	"\x20\x00\x00\x00\x54\xea\xa5\xd9"
	"__init_waitqueue_head\0\0\0"
	"\x18\x00\x00\x00\x74\x00\xe7\x74"
	"kthread_bind\0\0\0\0"
	"\x34\x00\x00\x00\x41\x39\x8a\xb3"
	"pcie_capability_clear_and_set_word_unlocked\0"
	"\x10\x00\x00\x00\xa6\x50\xba\x15"
	"jiffies\0"
	"\x20\x00\x00\x00\x2c\xe6\x42\x81"
	"kthread_create_on_node\0\0"
	"\x20\x00\x00\x00\x51\x8e\x4c\x19"
	"dma_set_coherent_mask\0\0\0"
	"\x10\x00\x00\x00\xfd\xf9\x3f\x3c"
	"sprintf\0"
	"\x2c\x00\x00\x00\x61\xe5\x48\xa6"
	"__ubsan_handle_shift_out_of_bounds\0\0"
	"\x18\x00\x00\x00\xa3\xef\x8b\xf1"
	"dma_free_attrs\0\0"
	"\x10\x00\x00\x00\x97\x82\x9e\x99"
	"vfree\0\0\0"
	"\x24\x00\x00\x00\x33\xb3\x91\x60"
	"unregister_chrdev_region\0\0\0\0"
	"\x18\x00\x00\x00\x38\xf0\x13\x32"
	"mutex_unlock\0\0\0\0"
	"\x1c\x00\x00\x00\x19\xac\x46\xa1"
	"pci_release_regions\0"
	"\x10\x00\x00\x00\xe4\x15\xe2\xfb"
	"sg_next\0"
	"\x14\x00\x00\x00\xaf\x3f\xa1\xf5"
	"__folio_put\0"
	"\x18\x00\x00\x00\xdf\xd3\x29\x67"
	"__get_user_4\0\0\0\0"
	"\x1c\x00\x00\x00\x32\x89\xb5\x28"
	"kobject_set_name\0\0\0\0"
	"\x18\x00\x00\x00\xf2\x79\x84\x2f"
	"device_destroy\0\0"
	"\x1c\x00\x00\x00\x65\x62\xf5\x2c"
	"__dynamic_pr_debug\0\0"
	"\x1c\x00\x00\x00\x80\xa0\xab\x63"
	"set_page_dirty_lock\0"
	"\x1c\x00\x00\x00\xaa\x0b\x25\xd2"
	"pci_disable_msix\0\0\0\0"
	"\x1c\x00\x00\x00\x52\x85\x06\xc6"
	"pci_disable_device\0\0"
	"\x18\x00\x00\x00\x7c\xae\x7e\xd6"
	"boot_cpu_data\0\0\0"
	"\x18\x00\x00\x00\x1f\x8f\x1d\x31"
	"pcie_set_readrq\0"
	"\x18\x00\x00\x00\x97\x48\xbc\x66"
	"dma_set_mask\0\0\0\0"
	"\x1c\x00\x00\x00\x3c\xc8\xdf\x00"
	"dma_unmap_sg_attrs\0\0"
	"\x18\x00\x00\x00\x19\x4e\x00\x34"
	"kmalloc_trace\0\0\0"
	"\x1c\x00\x00\x00\xeb\x10\xcf\x46"
	"cachemode2protval\0\0\0"
	"\x20\x00\x00\x00\x16\x5d\x1e\x13"
	"pci_read_config_byte\0\0\0\0"
	"\x2c\x00\x00\x00\xc6\xfa\xb1\x54"
	"__ubsan_handle_load_invalid_value\0\0\0"
	"\x10\x00\x00\x00\x8f\x68\xee\xd6"
	"vmalloc\0"
	"\x20\x00\x00\x00\x44\x0a\x47\x24"
	"pci_write_config_word\0\0\0"
	"\x1c\x00\x00\x00\x34\x4b\xb5\xb5"
	"_raw_spin_unlock\0\0\0\0"
	"\x14\x00\x00\x00\x24\x87\x65\x5c"
	"cdev_init\0\0\0"
	"\x14\x00\x00\x00\x45\x3a\x23\xeb"
	"__kmalloc\0\0\0"
	"\x20\x00\x00\x00\x5d\x7b\xc1\xe2"
	"__SCT__might_resched\0\0\0\0"
	"\x18\x00\x00\x00\x52\x57\xa3\x91"
	"kmalloc_caches\0\0"
	"\x14\x00\x00\x00\xb1\xd2\x8d\xd5"
	"cdev_del\0\0\0\0"
	"\x1c\x00\x00\x00\xea\x31\x28\x15"
	"kmem_cache_destroy\0\0"
	"\x1c\x00\x00\x00\x13\xe8\xb7\x2f"
	"dma_map_sg_attrs\0\0\0\0"
	"\x14\x00\x00\x00\xd3\x85\x33\x2d"
	"system_wq\0\0\0"
	"\x18\x00\x00\x00\x3a\x0a\xd8\xfc"
	"module_layout\0\0\0"
	"\x00\x00\x00\x00\x00\x00\x00\x00";

MODULE_INFO(depends, "");

MODULE_ALIAS("pci:v000010EEd00009048sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v000010EEd00009044sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v000010EEd00009042sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v000010EEd00009041sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v000010EEd0000903Fsv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v000010EEd00009038sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v000010EEd00009028sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v000010EEd00009018sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v000010EEd00009034sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v000010EEd00009024sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v000010EEd00009014sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v000010EEd00009032sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v000010EEd00009022sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v000010EEd00009012sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v000010EEd00009031sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v000010EEd00009021sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v000010EEd00009011sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v000010EEd00008011sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v000010EEd00008012sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v000010EEd00008014sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v000010EEd00008018sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v000010EEd00008021sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v000010EEd00008022sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v000010EEd00008024sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v000010EEd00008028sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v000010EEd00008031sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v000010EEd00008032sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v000010EEd00008034sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v000010EEd00008038sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v000010EEd00007011sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v000010EEd00007012sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v000010EEd00007014sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v000010EEd00007018sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v000010EEd00007021sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v000010EEd00007022sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v000010EEd00007024sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v000010EEd00007028sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v000010EEd00007031sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v000010EEd00007032sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v000010EEd00007034sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v000010EEd00007038sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v000010EEd00006828sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v000010EEd00006830sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v000010EEd00006928sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v000010EEd00006930sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v000010EEd00006A28sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v000010EEd00006A30sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v000010EEd00006D30sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v000010EEd00004808sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v000010EEd00004828sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v000010EEd00004908sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v000010EEd00004A28sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v000010EEd00004B28sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v000010EEd00002808sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v00001D0Fd0000F000sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v00001D0Fd0000F001sv*sd*bc*sc*i*");

MODULE_INFO(srcversion, "6C2BE7A3C77B0EF9950C5CE");

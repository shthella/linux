@@ -2908,8 +2908,13 @@ static void transfer_destroy(struct xdma_dev *xdev, struct xdma_transfer *xfer)
		struct sg_table *sgt = xfer->sgt;

		if (sgt->nents) {
#if KERNEL_VERSION(5, 17, 0) > LINUX_VERSION_CODE
			pci_unmap_sg(xdev->pdev, sgt->sgl, sgt->nents,
				     xfer->dir);
#else
			dma_unmap_sg(&xdev->pdev->dev, sgt->sgl, sgt->nents,
				     xfer->dir);
#endif
			sgt->nents = 0;
		}
	}
@@ -3192,8 +3197,13 @@ ssize_t xdma_xfer_aperture(struct xdma_engine *engine, bool write, u64 ep_addr,
	}

	if (!dma_mapped) {
#if KERNEL_VERSION(5, 17, 0) > LINUX_VERSION_CODE
		sgt->nents = pci_map_sg(xdev->pdev, sgt->sgl, sgt->orig_nents,
					dir);
#else
		sgt->nents = dma_map_sg(&xdev->pdev->dev, sgt->sgl,
                                        sgt->orig_nents, dir);
#endif
		if (!sgt->nents) {
			pr_info("map sgl failed, sgt 0x%p.\n", sgt);
			return -EIO;
@@ -3259,7 +3269,7 @@ ssize_t xdma_xfer_aperture(struct xdma_engine *engine, bool write, u64 ep_addr,
		sg = req->sg;
		ep_addr = req->ep_addr + (req->offset & (aperture - 1));
		i = req->sg_idx;
		

		for (sg = req->sg; i < sg_max && desc_idx < desc_max;
			i++, sg = sg_next(sg)) {
			dma_addr_t addr = sg_dma_address(sg);
@@ -3292,7 +3302,7 @@ ssize_t xdma_xfer_aperture(struct xdma_engine *engine, bool write, u64 ep_addr,
				ep_addr += len;
				addr += len;
				tlen -= len;
				

				desc_idx++;
				desc_cnt++;
				if (desc_idx == desc_max)
@@ -3304,7 +3314,7 @@ ssize_t xdma_xfer_aperture(struct xdma_engine *engine, bool write, u64 ep_addr,
			else
				break;
		}
		

		req->sg_offset = sg_offset;
		req->sg_idx = i;

@@ -3434,7 +3444,11 @@ ssize_t xdma_xfer_aperture(struct xdma_engine *engine, bool write, u64 ep_addr,

unmap_sgl:
	if (!dma_mapped && sgt->nents) {
#if KERNEL_VERSION(5, 17, 0) > LINUX_VERSION_CODE
		pci_unmap_sg(xdev->pdev, sgt->sgl, sgt->orig_nents, dir);
#else
		dma_unmap_sg(&xdev->pdev->dev, sgt->sgl, sgt->orig_nents, dir);
#endif
		sgt->nents = 0;
	}

@@ -3504,7 +3518,11 @@ ssize_t xdma_xfer_submit(void *dev_hndl, int channel, bool write, u64 ep_addr,
	}

	if (!dma_mapped) {
#if KERNEL_VERSION(5, 17, 0) > LINUX_VERSION_CODE
		nents = pci_map_sg(xdev->pdev, sg, sgt->orig_nents, dir);
#else
		nents = dma_map_sg(&xdev->pdev->dev, sg, sgt->orig_nents, dir);
#endif
		if (!nents) {
			pr_info("map sgl failed, sgt 0x%p.\n", sgt);
			return -EIO;
@@ -3660,7 +3678,11 @@ ssize_t xdma_xfer_submit(void *dev_hndl, int channel, bool write, u64 ep_addr,

unmap_sgl:
	if (!dma_mapped && sgt->nents) {
#if KERNEL_VERSION(5, 17, 0) > LINUX_VERSION_CODE
		pci_unmap_sg(xdev->pdev, sgt->sgl, sgt->orig_nents, dir);
#else
		dma_unmap_sg(&xdev->pdev->dev, sgt->sgl, sgt->orig_nents, dir);
#endif
		sgt->nents = 0;
	}

@@ -3781,7 +3803,11 @@ ssize_t xdma_xfer_completion(void *cb_hndl, void *dev_hndl, int channel,

unmap_sgl:
	if (!dma_mapped && sgt->nents) {
#if KERNEL_VERSION(5, 17, 0) > LINUX_VERSION_CODE
		pci_unmap_sg(xdev->pdev, sgt->sgl, sgt->orig_nents, dir);
#else
		dma_unmap_sg(&xdev->pdev->dev, sgt->sgl, sgt->orig_nents, dir);
#endif
		sgt->nents = 0;
	}

@@ -3855,7 +3881,11 @@ ssize_t xdma_xfer_submit_nowait(void *cb_hndl, void *dev_hndl, int channel,
	}

	if (!dma_mapped) {
#if KERNEL_VERSION(5, 17, 0) > LINUX_VERSION_CODE
		nents = pci_map_sg(xdev->pdev, sg, sgt->orig_nents, dir);
#else
		nents = dma_map_sg(&xdev->pdev->dev, sg, sgt->orig_nents, dir);
#endif
		if (!nents) {
			pr_info("map sgl failed, sgt 0x%p.\n", sgt);
			return -EIO;
@@ -3895,8 +3925,13 @@ ssize_t xdma_xfer_submit_nowait(void *cb_hndl, void *dev_hndl, int channel,
			pr_info("transfer_init failed\n");

			if (!dma_mapped && sgt->nents) {
#if KERNEL_VERSION(5, 17, 0) > LINUX_VERSION_CODE
				pci_unmap_sg(xdev->pdev, sgt->sgl,
						sgt->orig_nents, dir);
#else
				dma_unmap_sg(&xdev->pdev->dev, sgt->sgl,
						sgt->orig_nents, dir);
#endif
				sgt->nents = 0;
			}

@@ -3943,7 +3978,11 @@ ssize_t xdma_xfer_submit_nowait(void *cb_hndl, void *dev_hndl, int channel,

unmap_sgl:
	if (!dma_mapped && sgt->nents) {
#if KERNEL_VERSION(5, 17, 0) > LINUX_VERSION_CODE
		pci_unmap_sg(xdev->pdev, sgt->sgl, sgt->orig_nents, dir);
#else
		dma_unmap_sg(&xdev->pdev->dev, sgt->sgl, sgt->orig_nents, dir);
#endif
		sgt->nents = 0;
	}

@@ -4191,16 +4230,16 @@ static int set_dma_mask(struct pci_dev *pdev)

	dbg_init("sizeof(dma_addr_t) == %ld\n", sizeof(dma_addr_t));
	/* 64-bit addressing capability for XDMA? */
	if (!pci_set_dma_mask(pdev, DMA_BIT_MASK(64))) {
	if (!dma_set_mask(&pdev->dev, DMA_BIT_MASK(64))) {
		/* query for DMA transfer */
		/* @see Documentation/DMA-mapping.txt */
		dbg_init("pci_set_dma_mask()\n");
		/* use 64-bit DMA */
		dbg_init("Using a 64-bit DMA mask.\n");
		pci_set_consistent_dma_mask(pdev, DMA_BIT_MASK(64));
	} else if (!pci_set_dma_mask(pdev, DMA_BIT_MASK(32))) {
		dma_set_coherent_mask(&pdev->dev, DMA_BIT_MASK(64));
	} else if (!dma_set_mask(&pdev->dev, DMA_BIT_MASK(32))) {
		dbg_init("Could not set 64-bit DMA mask.\n");
		pci_set_consistent_dma_mask(pdev, DMA_BIT_MASK(32));
		dma_set_coherent_mask(&pdev->dev, DMA_BIT_MASK(32));
		/* use 32-bit DMA */
		dbg_init("Using a 32-bit DMA mask.\n");
	} else {

